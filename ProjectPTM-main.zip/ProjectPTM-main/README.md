# ProjectPTM

2nd Year Project on Advanced Program Develpoment at The College of Management Academic Studies.

This is a Flight simulator and anomaly detector project.

This application examine and display your flight, locate any anomalys on your flight compering a built-in regular flight data using linear regression,Welzl and ZScore algorithms.
The application connects and display the flight via FlightGear simulator 2020.3.

The Application have a media control planel where you can upload your flight and control the simulator speed,time step and more.
In addition, the application display flight data on a board using graphs,gauges, sliders and bars.
also, while using the anomaly detections algorithms the application will display those real time detections for the selected feature.
